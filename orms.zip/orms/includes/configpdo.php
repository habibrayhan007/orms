<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "sms";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>